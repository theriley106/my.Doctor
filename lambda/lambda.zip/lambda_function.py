import requests
import random

def returnSpeech(speech, endSession=True, text="", title=""):
	return {
		"version": "1.0",
		"sessionAttributes": {},
		"response": {
		"outputSpeech": {
		"type": "PlainText",
		"text": speech
			},
			"directives": [{
                "type": "Display.RenderTemplate",
                "template": {
                    "type": "BodyTemplate1",
                    "token": "T123",
                    "backButton": "HIDDEN",
                    "backgroundImage": {
                        "contentDescription": "Uber Logo",
                        "sources": [{
                            "url": "https://s3.amazonaws.com/christopherlambert/uber-logo.png"
                        }]
                    },
                    "title": title,
                    "textContent": {
                        "primaryText": {
                            "text": text,
                            "type": "PlainText"
                        }
                    }
                }
            }],
			"shouldEndSession": endSession
		  }
		}

def lambda_handler(event, context):
	if event["request"]["type"] == "LaunchRequest":
        requests.post("https://my-doctor-alexa.herokuapp.com/notification?message=Test&patient=213")
		return returnSpeech('I dont know l oh l.  Why would i know that.  I am not a doctor.  ')

if __name__ == '__main__':
	pass
